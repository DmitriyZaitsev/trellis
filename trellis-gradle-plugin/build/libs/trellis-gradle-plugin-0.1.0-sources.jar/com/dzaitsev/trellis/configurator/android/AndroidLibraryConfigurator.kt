package com.dzaitsev.trellis.configurator.android

import com.android.build.api.dsl.LibraryExtension
import com.dzaitsev.trellis.Module
import com.dzaitsev.trellis.android.AndroidAttrs
import com.dzaitsev.trellis.PluginIds
import com.dzaitsev.trellis.plugin.Configurator
import com.dzaitsev.trellis.plugin.ProjectExtension
import org.gradle.api.Project
import org.gradle.kotlin.dsl.configure

/**
 * Configures the `com.android.library` extension for a [Module.AndroidLibrary].
 *
 * Runs before the module's own script, so values set here are defaults that the module's
 * `android { }` block can override.
 */
public class AndroidLibraryConfigurator(private val androidAttrs: AndroidAttrs.Native) :
    Configurator<Module, ProjectExtension> {
    override fun configure(project: Project, module: Module, extension: ProjectExtension) {
        project.pluginManager.withPlugin(PluginIds.ANDROID_LIBRARY) {
            project.extensions.configure<LibraryExtension> {
                configureCommonAndroid(project, androidAttrs, extension)

                val consumerRules = project.file("consumer-rules.pro")
                if (consumerRules.exists()) {
                    defaultConfig.consumerProguardFiles(consumerRules)
                }

                productFlavors {
                    androidAttrs.flavors.forEach { flavor ->
                        create(flavor.flavorName) {
                            dimension = flavor.dimension
                            isDefault = flavor.isDefault
                        }
                    }
                }
            }
        }
    }
}
